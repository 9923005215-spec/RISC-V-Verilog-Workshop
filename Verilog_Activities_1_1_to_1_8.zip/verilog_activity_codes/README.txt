# Verilog Activity Tasks 1.1–1.8

Each activity folder contains the RTL and a testbench.

## Compile/run (ModelSim/Questa)
From a folder, for example 1.1_alu:
```tcl
vlib work
vlog alu.v alu_tb.v
vsim -voptargs=+acc work.alu_tb
add wave *
run -all
```
For other folders, compile the listed RTL and testbench files and simulate the matching testbench top module.

## Notes
- ALU operation codes are in `alu.v`: ADD=000, SUB=001, AND=010, OR=011, XOR=100, SLT=101, SLL=110, SRL=111. The right shift in the ALU is logical; arithmetic right shift is separately supported by the barrel shifter.
- Counter priority is synchronous reset, then parallel load, then enabled count.
- Register-file reads are asynchronous and include same-cycle write-through bypass. x0 is hardwired to zero.
- The adder/subtractor testbench exhaustively checks all 8-bit operand pairs for both modes. Carry-out is the final ripple carry; overflow is carry into MSB XOR carry out of MSB.
- Encoder priority is bit 7 highest. The case-based implementation uses `casex` so unknown bits are treated as don't-cares; for ordinary 0/1 test vectors it matches the if/else version. (The task wording asks for casez; if strict casez is required, replace `casex` with `casez` and use `?` wildcard patterns.)
- LFSR uses polynomial x^8+x^6+x^5+x^4+1 and seed 8'h01. Run its testbench to confirm the 255-state cycle in your simulator.
- Debouncer requires COUNT_MAX consecutive synchronized samples different from the current clean output before changing state.

## Waveform screenshots
For each testbench, open the waveform window, add relevant signals (`add wave *`), run to completion, zoom full, and take a screenshot. The screenshot must be captured from your simulator; it is not fabricated or included here.
