module edge_detect(input clk,reset,signal_in, output reg rise_pulse);
    reg sync1,sync2,signal_d;
    always @(posedge clk) begin
        if(reset) begin
            sync1<=0; sync2<=0; signal_d<=0; rise_pulse<=0;
        end else begin
            sync1<=signal_in;
            sync2<=sync1;
            signal_d<=sync2;
            rise_pulse<=sync2 & ~signal_d;
        end
    end
endmodule
