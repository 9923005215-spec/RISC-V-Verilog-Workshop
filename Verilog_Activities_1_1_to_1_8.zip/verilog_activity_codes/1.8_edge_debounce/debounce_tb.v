`timescale 1ns/1ps
module debounce_tb;
    reg clk=0,reset,noisy_in;
    wire clean_out,rise_pulse;
    debounce #(.COUNT_MAX(4),.WIDTH(3)) db(clk,reset,noisy_in,clean_out);
    edge_detect ed(clk,reset,clean_out,rise_pulse);
    always #5 clk=~clk;
    initial begin
        reset=1; noisy_in=0;
        repeat(3) @(negedge clk);
        reset=0;
        // Simulate contact bounce before a stable press.
        noisy_in=1; #7; noisy_in=0; #6; noisy_in=1; #5;
        noisy_in=0; #8; noisy_in=1;
        repeat(12) @(negedge clk);
        // Release with bounce.
        noisy_in=0; #6; noisy_in=1; #5; noisy_in=0;
        repeat(12) @(negedge clk);
        $finish;
    end
endmodule
