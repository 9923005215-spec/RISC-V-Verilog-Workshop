module debounce #(parameter COUNT_MAX=4, WIDTH=3) (
    input clk,reset,noisy_in,
    output reg clean_out
);
    reg sync1,sync2;
    reg [WIDTH-1:0] count;
    always @(posedge clk) begin
        if(reset) begin
            sync1<=0; sync2<=0; count<=0; clean_out<=0;
        end else begin
            sync1<=noisy_in;
            sync2<=sync1;
            if(sync2==clean_out)
                count<=0;
            else if(count==COUNT_MAX-1) begin
                clean_out<=sync2;
                count<=0;
            end else
                count<=count+1'b1;
        end
    end
endmodule
